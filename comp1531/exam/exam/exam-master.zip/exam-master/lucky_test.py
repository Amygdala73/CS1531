from lucky import lucky

def test_sample():
    assert lucky(1, 19, 4) == [1,3,7,9,13,15]
