def wordsquare(words):
    pass
