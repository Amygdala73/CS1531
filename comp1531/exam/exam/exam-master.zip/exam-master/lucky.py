def lucky(startNumber, endNumber, numberOfRemoves):
    pass
