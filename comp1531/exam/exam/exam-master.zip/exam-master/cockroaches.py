def decontaminate(filenames):
    pass