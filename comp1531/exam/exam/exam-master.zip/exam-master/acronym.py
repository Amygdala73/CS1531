def acronym_make(inputs):
    pass
