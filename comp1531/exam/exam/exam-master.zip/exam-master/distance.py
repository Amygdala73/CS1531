def longest_distance(elements):
    pass