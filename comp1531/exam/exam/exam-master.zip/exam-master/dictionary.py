def construct_dict(keys, values):
    pass
