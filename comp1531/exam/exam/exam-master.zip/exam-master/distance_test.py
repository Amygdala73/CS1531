from distance import longest_distance

def test_sample():
    assert(longest_distance([1,2,3,1,4]) == 3)